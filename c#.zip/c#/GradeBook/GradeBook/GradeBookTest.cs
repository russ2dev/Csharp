﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradeBook
{
    public class GradeBookTest
    {
       public static void Main(string[] args)
        {
            GradeBook myGradeBook = new GradeBook();

            Console.WriteLine("Please enter the course name: ");
            string nameOfCourse = Console.ReadLine();
            Console.WriteLine();

            myGradeBook.DisplayMessage(nameOfCourse);
        }
    }
}
