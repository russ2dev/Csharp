﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradeBook
{
    public class GradeBook
    {
        public void DisplayMessage(string courseName)
        {
            Console.WriteLine("Welcome to the grade book for\n{0}!",
                courseName);
        }
    }
}